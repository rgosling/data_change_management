/*
    Note:
    Example from https://www.mssqltips.com/sqlservertip/6762/sql-server-change-tracking-track-columns-updated/

	Official Documentation: https://learn.microsoft.com/en-us/sql/relational-databases/system-functions/changetable-transact-sql?view=sql-server-ver16


*/

ALTER DATABASE [AdventureWorksLT2019] SET CHANGE_TRACKING=ON
GO
USE [AdventureWorksLT2019]
GO
ALTER TABLE [SalesLT].[Customer] ENABLE CHANGE_TRACKING WITH(TRACK_COLUMNS_UPDATED = ON)
GO

--A) Use CHANGE_TRACKING_CURRENT_VERSION() to get the current database version which will be used next time when identifying changes.
--B) The CHANGETABLE (CHANGES) table function: Returns tracking information since the version specified. The arguments are the table name and the change version number.
--C) The CHANGETABLE (VERSION) table function: Returns the latest Change Tracking information for the current rows in a table including the change version number and the change context if used. This table function arguments are the user table and the primary key columns of that table.
--D) The WITH CHANGE_TRACKING_CONTEXT (context): Used to mark the changed records to easily be identified or selected later. The context is a string converted to varbinary (128).
--E) Use CHANGE_TRACKING_MIN_VALID_VERSION() to see the minimum version for which you can obtain changes. This value is related to the retention period set for change tracking.
--F) Use CHANGE_TRACKING_IS_COLUMN_IN_MASK() to determine is a specific column was updated or not. Can be used in the WHERE clause to only return records if a specific column changed.

--Update: Reassign some customer to SalesPerson = 'adventure-works\JimEvans1'.
DECLARE @Context varbinary(128) = CAST('1st Update - SalesPerson' AS varbinary(128));
WITH CHANGE_TRACKING_CONTEXT (@Context)  
 UPDATE SalesLT.Customer
SET [SalesPerson] = 'adventure-works\JimEvans1',
   [ModifiedDate] = GETDATE() 
WHERE CustomerID between 1 and 10;


--Check current Change Tracking Version Number
declare @version int;SELECT @Version= CHANGE_TRACKING_CURRENT_VERSION(); 
print @version
SELECT CHANGE_TRACKING_CURRENT_VERSION(); 

--Update just the ModifiedDate column for some customers.
DECLARE @Context varbinary(128) = CAST('2nd Update - ModifiedDate' AS varbinary(128));
 
WITH CHANGE_TRACKING_CONTEXT (@Context)  
UPDATE SalesLT.Customer
SET [ModifiedDate] = GETDATE() 
WHERE CustomerID between 30 and 40

 
--Check current Change Tracking Version Number
SELECT CHANGE_TRACKING_CURRENT_VERSION(); 

 
--Reassign some customer to SalesPerson AnneSmith2
DECLARE @Context varbinary(128) = CAST('3rd Update - SalesPerson' AS varbinary(128));
 
WITH CHANGE_TRACKING_CONTEXT (@Context)  
 UPDATE SalesLT.Customer
SET [SalesPerson] = 'adventure-works\AnneSmith2',
   [ModifiedDate] = GETDATE() 
WHERE CustomerID between 11 and 20

 
--Check current Change Tracking Version Number
SELECT CHANGE_TRACKING_CURRENT_VERSION(); 


--
--Retrieve All rows with CROSS APPLY Join to the CHANGETABLE (VERSION) Function, returning the row 
--VERSION number and the SYS_CHANGE_CONTEXT if used for updates.
SELECT c.[CustomerID], c.[SalesPerson], c.[ModifiedDate]
      ,CT.SYS_CHANGE_VERSION 
      ,CAST(ct.SYS_CHANGE_CONTEXT as varchar(255)) as 'SYS_CHANGE_CONTEXT'
      ,CT.CustomerID
FROM SalesLT.Customer AS c  
   CROSS APPLY CHANGETABLE(VERSION SalesLT.Customer, (CustomerID), (c.CustomerID)) AS CT
Where CT.SYS_CHANGE_VERSION IS NOT NULL
Order by CT.SYS_CHANGE_VERSION;


 --Set @ControlVersionNo to your value based on your change tracking version numbers.  It will 
 --be used as an argument in the CHANGETABLE (CHANGES) function.
DECLARE @ControlVersionNo int = 1  
 
--CHANGE_TRACKING_IS_COLUMN_IN_MASK to interprets the SYS_CHANGE_COLUMNS value that is 
--returned by the CHANGETABLE(CHANGES �) function.
SELECT CT.[CustomerID] --just PKeys
    ,CT.SYS_CHANGE_VERSION
    ,CT.SYS_CHANGE_OPERATION    
    ,CT.SYS_CHANGE_COLUMNS 
    ,CAST(CT.SYS_CHANGE_CONTEXT AS varchar(128)) as 'Marked Context'
    ,COLUMNPROPERTY(OBJECT_ID('SalesLT.Customer'), 'SalesPerson', 'ColumnId') as 'ColumnId'
    ,CHANGE_TRACKING_IS_COLUMN_IN_MASK(COLUMNPROPERTY(OBJECT_ID('SalesLT.Customer'), 'SalesPerson', 'ColumnId'), CT.SYS_CHANGE_COLUMNS) as 'SalesPerson Changed'
    ,CHANGE_TRACKING_IS_COLUMN_IN_MASK(COLUMNPROPERTY(OBJECT_ID('SalesLT.Customer'), 'ModifiedDate', 'ColumnId'), CT.SYS_CHANGE_COLUMNS)as 'ModifiedDate Changed'
 
FROM CHANGETABLE (CHANGES SalesLT.Customer, @ControlVersionNo) AS CT
WHERE CHANGE_TRACKING_IS_COLUMN_IN_MASK(COLUMNPROPERTY(OBJECT_ID('SalesLT.Customer'), 'SalesPerson', 'ColumnId'), CT.SYS_CHANGE_COLUMNS) = 1

--Return All Updates since the target Version!
DECLARE @ControlVersionNo int = 0
SELECT CT.SYS_CHANGE_VERSION, C.*
FROM CHANGETABLE (CHANGES SalesLT.Customer, @ControlVersionNo) AS CT
   inner join SalesLT.Customer C on C.[CustomerID] = CT.[CustomerID];
--

--Return All Updates since the target Version!
DECLARE @ControlVersionNo int = 2
SELECT CT.SYS_CHANGE_VERSION, C.*
FROM CHANGETABLE (CHANGES SalesLT.Customer, @ControlVersionNo) AS CT
   inner join SalesLT.Customer C on C.[CustomerID] = CT.[CustomerID];

 
--Return All Updates since the target Version only where the SalesPerson value changed!
DECLARE @ControlVersionNo int = 2
SELECT CT.SYS_CHANGE_VERSION, C.*
FROM CHANGETABLE (CHANGES SalesLT.Customer, @ControlVersionNo) AS CT
   inner join SalesLT.Customer C on C.[CustomerID] = CT.[CustomerID]
WHERE CHANGE_TRACKING_IS_COLUMN_IN_MASK(COLUMNPROPERTY(OBJECT_ID('SalesLT.Customer'), 'SalesPerson', 'ColumnId'), CT.SYS_CHANGE_COLUMNS) = 1
 and CT.SYS_CHANGE_OPERATION = 'U'; --Updates Only
 --
 
--Return All Updates since the target Version only where the SalesPerson value changed and the SYS_CHANGE_CONTEXT= '3nd Update - SalesPerson'!
DECLARE @ControlVersionNo int = 0
SELECT CT.SYS_CHANGE_VERSION
      ,CAST(CT.SYS_CHANGE_CONTEXT AS varchar(128))
      , C.*
FROM CHANGETABLE (CHANGES SalesLT.Customer, @ControlVersionNo) AS CT
   inner join SalesLT.Customer C on C.[CustomerID] = CT.[CustomerID]
WHERE CT.SYS_CHANGE_CONTEXT = CAST('3rd Update - SalesPerson' AS varbinary(128))
 and CHANGE_TRACKING_IS_COLUMN_IN_MASK(COLUMNPROPERTY(OBJECT_ID('SalesLT.Customer'), 'SalesPerson', 'ColumnId'), CT.SYS_CHANGE_COLUMNS) = 1
 and CT.SYS_CHANGE_OPERATION = 'U'; --Updates Only

 --Check current Change Tracking Version Number
SELECT CHANGE_TRACKING_CURRENT_VERSION(); 